# Debutify 8.0


We’re thrilled to announce the latest updates in version 8.0, bringing new features, enhancements, and bug fixes to elevate the user experience.

Version 8.0 introduces exciting new sections and features to enhance the shopping experience. The Countdown Sale, Lookbook, and Parallax Image add visual appeal and urgency, making your site more engaging. New additions like the Cart Countdown Timer, Cart Benefits, and Add-On Cart will boost customer engagement and drive conversions.

## New Sections
- **Countdown Sale** – Create a sense of urgency with a time-limited sale countdown.
- **Lookbook** – Showcase your products in style with the new Lookbook feature.
- **Parallax Image** – Add dynamic visuals to your site with a sleek parallax scrolling effect.

## New Features
- **Cart Countdown Timer**  
  Keep your customers engaged with a countdown timer displayed on the product cart page and cart drawer.
  
- **Cart Benefits & Guarantees**  
  Highlight key benefits and guarantees to improve conversion rates.

- **Add-On Cart**  
  Allow customers to easily add optional products to their cart, shown prominently in the cart page and cart drawer.

## Feature Improvements
- **Client Convenience Enhancements**  
  - **Star Rating Widget** – Added a helpful warning for clients when using the star rating widget.
  - **Cart Testimonials Widget** – Improved the cart testimonial experience for a smoother shopping journey.
  
- **Quantity Breaks (Product Break)**  
  - New **Free Gift Product** option added to incentivize purchases.
  - Choose from two new **Badge Styles**:  
    - Simple  
    - Most Popular
  
- **Theme Settings**  
  - **Mobile Options** for H1, H2, and H3 (Line Height & Letter Spacing) to enhance mobile readability.
  - **Arrow Color Customization** added for greater styling control.

- **Slideshow**  
  - Updated mobile content position options with new placements: **Top**, **Inside**, and **Bottom**.
  
- **Customizable Products**  
  - Added a **Required Field** note for better clarity during product customization.

- **Agree to Terms**  
  - **Checkbox** value is now stored in local storage for a seamless shopping experience on return visits.
  - **Blocker Warning** now appears when the "Agree to Terms" feature is disabled.

- **QB & Product Bundles**  
  - **Apply Discount Code** directly to bundled products, making discounts easier to apply.

## Bug Fixes
  

- **Trust Badge Alignment**  
  - Corrected spacing and alignment issues with the Trust Badge.

- **Slideshow Mobile View**  
  - Addressed container width issues for mobile-friendly display.